# OpenInterview v4.1 — Public Mover & Versions Updater (No Code Changes)

This tool automates the **simplest** path to test v4.1 **in the same Repl**:
- Moves the `profile_v4_1_package` folder under `public/`
- Updates `public/data/versions.json` to point to the new static path
- Installs & runs tests inside the moved package (optional but default)

## How to use (Replit shell)

1) **Upload/Import** this ZIP at the root of your existing OpenInterview Repl.
2) In the Replit shell, run:
```bash
unzip -o mover_v4_1.zip
node mover/apply.js
```
3) Restart your main server (Stop → Run) and refresh your app.
4) Open: `/profile_v4_1_package/public/index.html` (or use your version picker).

## What it does (exactly)

- If `profile_v4_1_package` exists at repo root, it is **moved** to:
  `public/profile_v4_1_package`

- Updates (or creates) `public/data/versions.json` with this v4.1 entry:
```json
{
  "version": "4.1",
  "page": "profile_v4_1_package/public/index.html",
  "code": "profile_v4_1_package/"
}
```

- Runs inside `public/profile_v4_1_package`:
```bash
npm i
npm test   # guardrails + unit tests
```

> No code modifications are made to your v4.1 HTML/CSS/JS or to your server code.

## Rollback
If needed, you can move the folder back:
```bash
mv public/profile_v4_1_package profile_v4_1_package
```
And restore your previous `public/data/versions.json` from your VCS/backup.
