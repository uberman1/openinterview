# OpenInterview Versions (Replit-ready)

This project serves a self-executing index of profile page versions and the current profile page.

## Quick start (Replit)
1. Import this repo/folder to Replit.
2. Replit will detect `package.json`. Click **Run** (or it will run automatically).
3. Open the web preview — the server serves `profiles_v2.html` at the root.

## URLs
- Versions Index: `/` or `/profiles_v2.html`
- Current Profile Page: `/profile_pagev2.html`
- Data:
  - `/data/versions.json`
  - `/data/profiles.json`
  - `/data/original_profiles.json` (paste your original data here to override)
  - Code snapshots under `/data/code/`

## Updating versions
- Edit `data/versions.json` to add new rows (3.2, 3.3) or new sections (major 4).
- When you finalize a version, copy the HTML of `/public/profile_pagev2.html` to `/public/data/code/profile_vX_Y.txt` and update the `code` link in `versions.json`.
