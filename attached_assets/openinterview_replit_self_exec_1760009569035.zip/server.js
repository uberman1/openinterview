import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = process.env.PORT || 3000;

app.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  next();
});

app.use(express.static(path.join(__dirname, 'public')));

// Root -> versions index
app.get('/', (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'profiles_v2.html'));
});

app.listen(PORT, () => {
  console.log(`OpenInterview Versions server listening on http://localhost:${PORT}`);
});
